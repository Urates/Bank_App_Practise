import React from "react";
import "./style.css";

export const Homepage = () => {
    return (
        <div className="homepage">
            <div className="overlap">
                <div className="text-wrapper">Versatile Programmers</div>
                <div className="overlap-group">
                    <div className="group">
                        <div className="div-wrapper">
                            <div className="div">Logo</div>
                        </div>
                    </div>
                    <div className="group">
                        <div className="div-wrapper">
                            <div className="div">Logo</div>
                        </div>
                    </div>
                </div>
                <div className="overlap-2">
                    <div className="group-2">
                        <div className="rectangle" />
                        <div className="rectangle-2" />
                    </div>
                    <div className="text-wrapper-2">SIGN UP</div>
                    <div className="text-wrapper-3">SIGN IN</div>
                </div>
            </div>
            <div className="overlap-3">
                <div className="overlap-4">
                    <div className="text-wrapper-4">CONTACT US</div>
                </div>
                <div className="overlap-wrapper">
                    <div className="overlap-5">
                        <div className="rectangle-3" />
                        <div className="text-wrapper-5">NAME</div>
                        <div className="text-wrapper-6">Enter your name</div>
                    </div>
                </div>
                <div className="overlap-group-wrapper">
                    <div className="overlap-5">
                        <div className="rectangle-3" />
                        <div className="text-wrapper-7">EMAIL ADDRESS</div>
                        <div className="text-wrapper-6">Enter your email address</div>
                    </div>
                </div>
                <div className="group-3">
                    <div className="overlap-6">
                        <div className="rectangle-4" />
                        <div className="text-wrapper-7">SUBJECT</div>
                        <div className="text-wrapper-6">Write your query here</div>
                    </div>
                </div>
                <div className="group-4">
                    <div className="overlap-7">
                        <div className="text-wrapper-8">SUBMIT</div>
                    </div>
                </div>
            </div>
            <div className="overlap-8">
                <img className="bank-building" alt="Bank building" src="bank-building-1.png" />
                <div className="rectangle-5" />
                <div className="group-5">
                    <div className="group-6">
                        <div className="overlap-group-2">
                            <div className="ellipse" />
                            <img className="founded-icon" alt="Founded icon" src="founded-icon-removebg-preview-1.png" />
                        </div>
                    </div>
                    <div className="text-wrapper-9">Founded in 2023</div>
                </div>
                <div className="group-7">
                    <div className="div-2">
                        <div className="group-8">
                            <div className="group-9" />
                            <div className="group-10">
                                <div className="text-wrapper-10">Highly Secured</div>
                            </div>
                        </div>
                        <img className="privacy" alt="Privacy" src="privacy-1.png" />
                    </div>
                </div>
                <div className="group-11">
                    <div className="div-2">
                        <div className="group-8">
                            <div className="div-2">
                                <div className="group-9" />
                                <div className="group-10">
                                    <div className="text-wrapper-10">User Friendly</div>
                                </div>
                            </div>
                        </div>
                        <img className="element" alt="Element" src="4946408-1.png" />
                    </div>
                </div>
                <div className="rectangle-6" />
                <p className="versatile">
                    Versatile Programmers is a team of 5 programmers that was established in Capaciti tech accelerator Program
                    specialising in full stack software development. This team was then founded in October 2023.
                    <br />
                    <br />
                    The team takes its pride in a banking app that is highly secured. This is in response to the demanding
                    security requirements by bank users these days; we have developed the model for our App with those
                    requirements in mind.
                    <br />
                    <br />
                    The App is developed under a model that prioritises clear navigability, optimised operational speed,
                    interactive and intuitive user interface.
                </p>
            </div>
        </div>
    );
};


//This marks the end of the first page (homepage)

import React from "react";
import "./style.css";

export const SignUpPage = () => {
    return (
        <div className="sign-up-page">
            <div className="overlap">
                <div className="homepage">
                    <div className="overlap-group">
                        <div className="text-wrapper">Versatile Programmers</div>
                        <div className="div">
                            <div className="group">
                                <div className="div-wrapper">
                                    <div className="text-wrapper-2">Logo</div>
                                </div>
                            </div>
                            <div className="group">
                                <div className="div-wrapper">
                                    <div className="text-wrapper-2">Logo</div>
                                </div>
                            </div>
                        </div>
                        <div className="overlap-2">
                            <div className="group-2">
                                <div className="rectangle" />
                                <div className="rectangle-2" />
                            </div>
                            <div className="text-wrapper-3">SIGN UP</div>
                            <div className="text-wrapper-4">SIGN IN</div>
                        </div>
                    </div>
                    <div className="overlap-3">
                        <img className="bank-building" alt="Bank building" src="bank-building-1.png" />
                        <div className="rectangle-3" />
                    </div>
                    <div className="rectangle-4" />
                </div>
                <div className="text-wrapper-5">LATEST NEWS</div>
                <div className="rectangle-5" />
                <div className="text-wrapper-6">SIGN UP</div>
                <div className="group-wrapper">
                    <div className="overlap-group-wrapper">
                        <div className="overlap-group-2">
                            <div className="text-wrapper-7">REGISTER</div>
                        </div>
                    </div>
                </div>
                <div className="group-3">
                    <p className="p">The rising prime interest rate</p>
                    <div className="rectangle-6" />
                </div>
                <div className="group-4">
                    <p className="p">The bank has 100 000 new users in one month</p>
                    <div className="rectangle-6" />
                </div>
                <div className="group-5">
                    <p className="p">VP Bank sponsored CapaCiti-led Tech Innovation competition</p>
                    <div className="rectangle-6" />
                </div>
                <div className="group-6">
                    <p className="p">Discounted transactional charges for new users</p>
                    <div className="rectangle-6" />
                </div>
                <div className="group-7">
                    <div className="group-8">
                        <div className="group-9">
                            <div className="overlap-group-3">
                                <div className="group-10" />
                                <div className="text-wrapper-8">READ MORE</div>
                            </div>
                        </div>
                    </div>
                    <img className="arrow" alt="Arrow" src="arrow-1.svg" />
                </div>
            </div>
        </div>
    );
};

//This marks the end of the second page (SignUp Page)
